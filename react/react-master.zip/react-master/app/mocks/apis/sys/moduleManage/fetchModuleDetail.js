
module.exports = {
  data: {
    id: 2,
    resName: '基础信息',
    resType: 1,
    resModule: 'inedx',
    resKey: 'menu2',
    resIcon: 'null',
    sort: 1,
    status: 0,
  },
  msg: '操作成功',
  status: 1,
}
