
module.exports = {
  data: {
    list: [
      {
        id: 1,
        roleName: '超级管理员',
        sort: 0,
        type: 0,
        resources: [],
      },
      {
        id: 10080,
        roleName: '开发账号',
        sort: 2,
        resources: [],
      },
      {
        id: 10060,
        roleName: '测试',
        sort: 3,
        resources: [],
      },
      {
        id: 10100,
        roleName: '演示账号',
        sort: 3,
        resources: [],
      },
    ],
  },
  msg: '',
  errorCode: '',
  status: 1,
}
