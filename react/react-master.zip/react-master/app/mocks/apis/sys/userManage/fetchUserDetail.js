
module.exports = {
  data: {
    id: 10240,
    username: 'tgramxs',
    password: '123456',
    chineseName: '销售部',
    idcardNo: '332527198010230505',
    deptCode: '370200000000',
    phoneNo: '18969784568',
    status: 0,
    roleIds: [
      10100,
    ],
    gxdwdm: '370200000000',
  },
  msg: '',
  errorCode: '',
  status: 1,
}
