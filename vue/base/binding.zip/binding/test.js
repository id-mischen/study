
// function show(){
//     message = 'rainy';
// }
// show();
// console.log(message);

// function show(){
//
// }
// console.log( typeof null);
// console.log(typeof  show);

// let o = new Object({
//     name: 'rainy'
// });
// console.log(o.constructor);
// console.log(o.hasOwnProperty('namew'));
// console.log(o.toString());
// console.log(o.propertyIsEnumerable("name"));
// console.log(o.isPrototypeOf(o));
// console.log(o.toLocaleString());
// console.log(o.valueOf());

// let arr = [1,2,3];
// arr.length = 2;
// console.log(arr);

// let arr = ["red","green","blue"];
// console.log(arr.valueOf());
// console.log(arr.toString());

//封装 every some filter map foreach

let arr = [1,2,3,4,5];

let isEql = arr.every(function (item, index , arr) {
   return item > 1 ;
});

function every(){

}

console.log(isEql);











